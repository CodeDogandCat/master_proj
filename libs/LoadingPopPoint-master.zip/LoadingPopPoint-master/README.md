
 [ ![Download](https://api.bintray.com/packages/liangpengfei/maven/loadingPopPoint/images/download.svg) ](https://bintray.com/liangpengfei/maven/loadingPopPoint/_latestVersion)
 
 [![Android Arsenal](https://img.shields.io/badge/Android%20Arsenal-LoadingPopPoint-green.svg?style=flat)](https://android-arsenal.com/details/1/2717)
# LoadingPopPoint
this is a view that three colorful point circle in the screen 

# Preview
It may looks like this 

![Imgur](http://i.imgur.com/wq0gInp.gif)

#Get Started

```
 repositories {
        // ...
        maven { url "https://jitpack.io" }
    }
 dependencies {
       compile 'com.github.liangpengfei:LoadingPopPoint:912651e54d'
	}
``` 

#Usage

XML

```
<xhome.uestcfei.com.loadingpoppoint.LoadingPopPoint
        android:layout_width="wrap_content"
        android:minHeight="50dp"
        android:layout_centerInParent="true"
        android:layout_height="wrap_content" />
```

#License

No license,You can share it as you like it! Wish you can learn some basic tips from my repository! 
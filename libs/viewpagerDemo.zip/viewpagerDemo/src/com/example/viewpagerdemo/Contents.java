package com.example.viewpagerdemo;

public class Contents {
	
	public static final String ZH = "zonghe";
	
	public static final String XW = "xinwen";
	
	public static final String YL = "yule";
	
	public static final String TY = "tiyu";
	
	
	
	

}

const LC = require('literallycanvas');

LC.init(document.getElementById('main'), {imageURLPrefix: "/build/lc-assets/img"})

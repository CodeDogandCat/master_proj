package com.github.dfqin.permissiondemo;

import java.util.List;

/**
 * Created by dfqin on 17/2/7.
 */

public class ContactInfo {
    /**
     * name
     */
    public String n = "";

    /**
     * phones
     */
    public List<String> p;

    /**
     * email
     *
     */
    public String m = "";

    /**
     * company
     */
    public String o = "";

    /**
     * address
     */
    public String a = "";
}

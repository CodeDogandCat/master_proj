/** Automatically generated file. DO NOT MODIFY */
package com.lt.bottomtabdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
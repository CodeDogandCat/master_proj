package com.lt.bottomtabdemo;

import java.util.ArrayList;
import java.util.List;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

import com.lt.bottomtabdemo.adapter.TabPageAdapter;
import com.lt.bottomtabdemo.fragment.ClassifyFragment;
import com.lt.bottomtabdemo.fragment.DiscoverFragment;
import com.lt.bottomtabdemo.fragment.HomeFragment;
import com.lt.bottomtabdemo.fragment.MeFragment;

public class MainActivity extends FragmentActivity implements
		OnPageChangeListener, OnCheckedChangeListener {

	private ViewPager mViewPager;
	private RadioGroup mRadioGroup;

	/**
	 * ��ť��ûѡ����ʾ��ͼ��
	 */
	private int[] unselectedIconIds = { R.drawable.ic_tab_home_gray,
			R.drawable.ic_tab_classify_gray, R.drawable.ic_tab_discover_gray,
			R.drawable.ic_tab_me_gray };
	/**
	 * ��ť��ѡ����ʾ��ͼ��
	 */
	private int[] selectedIconIds = { R.drawable.ic_tab_home_yellow,
			R.drawable.ic_tab_classify_yellow, R.drawable.ic_tab_discover_yellow,
			R.drawable.ic_tab_me_yellow };
	
	private List<Fragment> fragments = new ArrayList<Fragment>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		init();
		initView();
		selectPage(0); // Ĭ��ѡ����ҳ
	}

	protected void init() {
		Fragment homeFragment = new HomeFragment();
		Fragment classifyFragment = new ClassifyFragment();
		Fragment discoverFragment = new DiscoverFragment();
		Fragment meFragment = new MeFragment();
		fragments.add(homeFragment);
		fragments.add(classifyFragment);
		fragments.add(discoverFragment);
		fragments.add(meFragment);
	}

	private void initView() {
		mRadioGroup = (RadioGroup) findViewById(R.id.radioGroup);
		mViewPager = (ViewPager) findViewById(R.id.viewPager);
		mRadioGroup.setOnCheckedChangeListener(this);
		TabPageAdapter tabPageAdapter = new TabPageAdapter(
				getSupportFragmentManager(), fragments);
		mViewPager.setAdapter(tabPageAdapter);
		mViewPager.setOnPageChangeListener(this);
	}

	/**
	 * ѡ��ĳҳ
	 * @param position ҳ���λ��
	 */
	private void selectPage(int position) {
		// �����е�tab��icon��ɻ�ɫ��
		for (int i = 0; i < mRadioGroup.getChildCount(); i++) {
			Drawable gray = getResources().getDrawable(unselectedIconIds[i]);
			// �����٣����˲�����ʾͼƬ
			gray.setBounds(0, 0, gray.getMinimumWidth(),
					gray.getMinimumHeight());
			RadioButton child = (RadioButton) mRadioGroup.getChildAt(i);
			child.setCompoundDrawables(null, gray, null, null);
			child.setTextColor(getResources().getColor(
					R.color.dark_gray));
		}
		// �л�ҳ��
		mViewPager.setCurrentItem(position, false);
		// �ı�ͼ��
		Drawable yellow = getResources().getDrawable(selectedIconIds[position]);
		yellow.setBounds(0, 0, yellow.getMinimumWidth(),
				yellow.getMinimumHeight());
		RadioButton select = (RadioButton) mRadioGroup.getChildAt(position);
		select.setCompoundDrawables(null, yellow, null, null);
		select.setTextColor(getResources().getColor(
				R.color.yellow));
	}

	@Override
	public void onPageScrolled(int position, float positionOffset,
			int positionOffsetPixels) {

	}

	@Override
	public void onPageSelected(int position) {
		selectPage(position);
	}

	@Override
	public void onPageScrollStateChanged(int state) {

	}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		switch (checkedId) {
			case R.id.btn_home: // ��ҳѡ��
				selectPage(0);
				break;
			case R.id.btn_classify: // ����ѡ��
				selectPage(1);
				break;
			case R.id.btn_discover: // ����ѡ��
				selectPage(2);
				break;
			case R.id.btn_me: // ��������ѡ��
				selectPage(3);
				break;
		}
	}
}

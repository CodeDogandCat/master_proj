package cn.edu.hfut.lilei.shareboard.listener;


public interface FragmentListener {

    public void onFragmentUpdateListener(int item);

}
package cn.edu.hfut.lilei.shareboard.model;

import android.content.Context;

/**
 * Created by Bryant on 2017/5/9.
 */

public class ContextEvent {
    public Context context;
    public String from;
    public String to;
}

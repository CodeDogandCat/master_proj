package cn.edu.hfut.lilei.shareboard.model;

/**
 * Created by Bryant on 2017/5/3.
 */

public class Event {
    public int flag;
    public int position;
}

package cn.edu.hfut.lilei.shareboard.JsonEnity;


public class CommonJson {
    public int code;//返回码
    public String msg;//提示信息
    public int data;

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

}
